import React from 'react'
import './Navbar.css'
import {assets} from '../../assets/assets' 

const Navbar = () => {
  return (
    <div className='navbar'>
      <h1>HỆ THỐNG ĐIỂM DANH HỌC SINH</h1>
    </div>
  )
}

export default Navbar
