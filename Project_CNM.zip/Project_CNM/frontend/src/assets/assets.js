import logo from './logo.png'
import home from './home.png'
import info from './info.png'
import history from './history.png'
import list from './list.webp'

export const assets = {
    logo,
    home,
    info, 
    history,
    list
}